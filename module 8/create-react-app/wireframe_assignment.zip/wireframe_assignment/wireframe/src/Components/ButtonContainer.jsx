import React from 'react';
import {
    ButtonGet,
    ButtonGive
} from './index'


class ButtonContainer extends React.Component {
    render () {
        return (
            <div>
                <ButtonGet></ButtonGet>
                <ButtonGive></ButtonGive>
            </div>
        )
    }
}

export default ButtonContainer;