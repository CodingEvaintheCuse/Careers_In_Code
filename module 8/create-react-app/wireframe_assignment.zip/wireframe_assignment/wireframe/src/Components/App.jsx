import React from 'react';
import Header from './Header';
import Navbar from './Navbar';
import TextContainer from './TextContainer';
import ButtonContainer from './ButtonContainer';


class App extends React.Component{
    render(){
        return(
        <div>
            <Header></Header>>
            <Navbar></Navbar> 
            <TextContainer></TextContainer>>
            <ButtonContainer></ButtonContainer>
        </div>
        
    )
        
    }
}
export default App;