import React from 'react';

class TextContainer extends React.Component {
    render () {
        return
    }
}
export default TextContainer;
