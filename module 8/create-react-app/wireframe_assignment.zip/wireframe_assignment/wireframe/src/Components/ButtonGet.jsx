import React from 'react';

class ButtonGet extends React.Component {
    render () {
        return (
            <div>

            </div>
        )
    }
}

export default ButtonGet;