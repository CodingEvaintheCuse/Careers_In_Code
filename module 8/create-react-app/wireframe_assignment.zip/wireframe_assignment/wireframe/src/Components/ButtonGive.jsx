import React from 'react';

class ButtonGive extends React.Component {
    render () {
        return (
            <div>

            </div>
        )
    }
}

export default ButtonGive;