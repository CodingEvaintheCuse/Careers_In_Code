#!/bin/bash

source ./vars.sh
docker exec -it $NAME /bin/bash