#!/bin/bash

source ./vars.sh
docker stop $NAME